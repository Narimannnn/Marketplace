package org.example.controllers;

import org.example.entities.Electronic;
import org.example.repositories.ElectronicsRepository;
import org.example.selectors.categories.ElectronicCategory;

import java.sql.SQLException;
import java.util.ArrayList;

public class ElectronicController {
    private final ElectronicsRepository repository;

    public ElectronicController(ElectronicsRepository repository) {
        this.repository = repository;
    }
    public ArrayList<Electronic>  getElectronic(ElectronicCategory electronicCategory,String sql) throws SQLException, ClassNotFoundException {

        ArrayList<Electronic> list = new ArrayList<>();
        list = repository.getElectronic(electronicCategory,sql);
        for(int i = 0; i < list.size();i++){
            System.out.println(list.get(i).toString());
        }
         return list;

    }

}
