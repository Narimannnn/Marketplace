package org.example.controllers;

import org.example.entities.User;
import org.example.repositories.IUserRepository;

import java.sql.SQLException;

public class UserController {
    private final IUserRepository repository;

    public UserController(IUserRepository repository) {
        this.repository = repository;
    }
    public String createUser(String login,String password) throws SQLException {
        User user = User.createInstance();
        user.setLogin(login);
        user.setPassword(password);
        boolean created = repository.createUser(user);
        return (created ? "User was created!" : "User creation was failed!");
    }
    public String isLogin(String login,String password)throws SQLException{
        boolean sisLogin = repository.userLogin(login,password);
        if(sisLogin){
            User user = User.createInstance();
            user.setLogin(login);
            user.setPassword(password);
        }
        return (sisLogin ? "You have been successfully log in!" : "Login failed or not found user with this login or password!");
    }
}
