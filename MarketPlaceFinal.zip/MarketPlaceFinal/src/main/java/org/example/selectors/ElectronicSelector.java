package org.example.selectors;

import org.example.entities.* ;
import org.example.selectors.categories.ElectronicCategory;
import org.example.selectors.categories.ElectronicCategoryType;

import java.util.ArrayList;

public class ElectronicSelector {
    public Electronic createElectronic(ElectronicCategory electronicCategory, ElectronicCategoryType electronicCategoryType, String brandName, ArrayList<Object> list) {
        Electronic electronic = null;
        if(ElectronicCategory.Phone == electronicCategory){
            if(ElectronicCategoryType.SmartPhone == electronicCategoryType){
                if(brandName == "Iphone"){
                    electronic = new Iphone((Integer) list.get(0), (Double) list.get(10), (Integer) list.get(11), (String) list.get(8), (String) list.get(3), (String) list.get(4), (Integer) list.get(5), (String) list.get(6), (String) list.get(9));
                }else
                if(brandName == "Samsung"){
                    electronic= new Samsung((Integer) list.get(0), (Double) list.get(10), (Integer) list.get(11), (String) list.get(8), (String) list.get(3), (String) list.get(4), (Integer) list.get(5), (String) list.get(6), (String) list.get(9));
                } else
                if(brandName == "Xiaomi"){
                    electronic =new Xiaomi((Integer) list.get(0), (Double) list.get(10), (Integer) list.get(11), (String) list.get(8), (String) list.get(3), (String) list.get(4), (Integer) list.get(5), (String) list.get(6), (String) list.get(9));
                } else {
                    electronic = new PhoneOtherBrands((Integer) list.get(0), (String) list.get(1),(Double) list.get(10), (Integer) list.get(11), (String) list.get(8), (String) list.get(3), (String) list.get(4), (Integer) list.get(5), (String) list.get(6), (String) list.get(9) );
                }
            }else if(ElectronicCategoryType.NonSmartphone == electronicCategoryType){
                electronic = new NonSmartphone((Integer) list.get(0), (String) list.get(1),(Double) list.get(10), (Integer) list.get(11), (String) list.get(8), (String) list.get(3), (String) list.get(4), (Integer) list.get(5), (String) list.get(6), (String) list.get(9) );

            }
        }else
        if(ElectronicCategory.Computer == electronicCategory) {
            if (ElectronicCategoryType.PersonalComputer == electronicCategoryType) {
                electronic = new PersonalComputer((Integer) list.get(0), (String) list.get(2), (Double) list.get(11), (Integer) list.get(12), (String) list.get(13), (String) list.get(3), (String) list.get(4), (Integer) list.get(5), (String) list.get(6), (String) list.get(7), (Integer) list.get(8), (Integer) list.get(9), (String) list.get(10));
            }
            if (ElectronicCategoryType.Laptop == electronicCategoryType) {
                electronic = new Laptops((Integer) list.get(0), (String) list.get(2), (Double) list.get(11), (Integer) list.get(12), (String) list.get(13), (String) list.get(3), (String) list.get(4), (Integer) list.get(5), (String) list.get(6), (String) list.get(7), (Integer) list.get(8), (Integer) list.get(9), (String) list.get(10));

            }
        }else
        if(ElectronicCategory.Tablet == electronicCategory){
            if(ElectronicCategoryType.Graphical ==electronicCategoryType){
                electronic = new Graphical((Integer) list.get(0),(String) list.get(3),(Double) list.get(9), (Integer) list.get(10), (String) list.get(8));
            }
            if(ElectronicCategoryType.Interactive ==electronicCategoryType){
                electronic = new Kids((Integer) list.get(0),(String) list.get(3),(Double) list.get(9), (Integer) list.get(10), (String) list.get(8));
            }
        }else
        if(ElectronicCategory.OtherElectronicDevice == electronicCategory){
            electronic = new OtherElectronicDevice((Integer) list.get(0),(String) list.get(1),(String) list.get(2), (Double) list.get(3), (Integer) list.get(4), (String) list.get(5));
        }
        return electronic;
    }
}
