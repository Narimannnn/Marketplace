package org.example.selectors.categories;

public enum ElectronicCategory {

    Phone,
    Computer,
    Tablet,
    OtherElectronicDevice

}
