package org.example.selectors.categories;

public enum ElectronicCategoryType {
    SmartPhone, NonSmartphone,
    PersonalComputer, Laptop,
    Graphical, Interactive
}
