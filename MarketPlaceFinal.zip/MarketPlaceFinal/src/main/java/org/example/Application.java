package org.example;

import org.example.controllers.ElectronicController;
import org.example.controllers.UserController;
import org.example.entities.*;
import org.example.selectors.categories.ElectronicCategory;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class Application {
    private static UserController controller = null;
    private static ElectronicController electronicController = null;
    private static final Scanner scanner = new Scanner(System.in);
    private static User user;
    public static ArrayList<Electronic> list = new ArrayList<>();

    public Application(UserController controller, ElectronicController electronicController) {
        Application.controller = controller;
        Application.electronicController = electronicController;
    }

    public static void StartMarketPlace() {
        while (true) {
            System.out.println("MarketPlace\n" +
                    "1.\tSearch item by filters\n" +
                    "2.\tSignin\n" +
                    "3.\tShow cart!\n" +
                    "4.\tLogout\n");
            try {
                int option = scanner.nextInt();
                scanner.nextLine();
                if(option == 1) Filters();
                else if(option == 2) {
                    if (User.getInstance()) {
                        System.out.println("You have already logged in!");
                        StartMarketPlace();
                    } else {
                        signIn();
                    }
                } else if(option == 3){
                    System.out.println(Cart.showCart(user));
                } else if(option == 4){
                    User.setInstance();
                    System.out.println("You have left your account!");
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

    }

    public static void signIn() {
        System.out.println("MarketPlace\n" +
                "1.\tRegistration\n" +
                "2.\tLogin\n" +
                "3.\tBack\n");
        try {
            int option = scanner.nextInt();
            scanner.nextLine();
            switch (option) {
                case 1:
                    System.out.println("Please enter username");
                    String username = scanner.nextLine();
                    System.out.println("Please enter password");
                    String password1 = scanner.nextLine();
                    System.out.println("Please repeat password");
                    String password2 = scanner.nextLine();
                    if (new String(password1).equals(password2)) {
                        String st = controller.createUser(username, password1);
                        System.out.println(st);
                        Cart.createInstance();
                    }
                    StartMarketPlace();
                case 2:
                    System.out.println("Please enter username");
                    String username1 = scanner.nextLine();
                    System.out.println("Please enter password");
                    String password3 = scanner.nextLine();
                    String st = controller.isLogin(username1, password3);
                    System.out.println(st);
                    Cart.createInstance();
                    StartMarketPlace();
                case 3:
                    StartMarketPlace();

            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    public static void Filters() throws SQLException, ClassNotFoundException {
        System.out.println("\n" +
                "1.\tPhone\n" +
                "2.\tComputer\n" +
                "3.\tTablets\n" +
                "4.\tOther devices\n" +
                "5.\tGo back!\n" +
                "\n"); //shows all items of electronics
        int n = scanner.nextInt();
        scanner.nextLine();
        switch (n) {
            case 1:
                PhoneFilters();//calls method that shows users phone filters(smart or nonsmartphones)
            case 2:ComputerFilter();
            case 3:TabletFilter();
            case 4:list = electronicController.getElectronic(ElectronicCategory.OtherElectronicDevice, "SELECT * FROM `otherelectronic`");
            BuyItem();
            case 5:
                StartMarketPlace(); //return user to previous method
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////Phone filters////////////////////////////////////////////////////////////////
    public static void PhoneFilters() throws SQLException, ClassNotFoundException {
        System.out.println("1.\tShow Phones\n" +
                "2.\tAdd filter Smartphones\n" +
                "3.\tAdd filter Non-SmartPhones\n" +
                "4.\tGo Back\n");
        int n = scanner.nextInt();
        scanner.nextLine();
        switch (n) {
            case 1:
                list = electronicController.getElectronic(ElectronicCategory.Phone, "SELECT * FROM phones");
                BuyItem();
            case 2:PhoneSmartphoneFilter();
            case 3:
                list = electronicController.getElectronic(ElectronicCategory.Phone, "SELECT * FROM phones WHERE `Category` = 'NonSmartphone'");
                BuyItem();
            case 4:
                Filters(); //return previous method
        }
    }

    public static void PhoneSmartphoneFilter() throws SQLException, ClassNotFoundException {
        System.out.println(
                "1.\tShow Phones\n" +
                        "2.\tIphone\n" +
                        "3.\tSamsung\n" +
                        "4.\tXiaomi\n" +
                        "5.\tOther Brands\n" +
                        "6.\tGo Back\n");
        int n = scanner.nextInt();
        scanner.nextLine();
        switch (n) {
            case 1:
                list = electronicController.getElectronic(ElectronicCategory.Phone, "SELECT * FROM phones WHERE `Category` = 'Smartphone'");
                BuyItem();
            case 2:
                PhoneSmartphoneIphoneFilter();//add filter Iphone
            case 3:
                PhoneSmartphoneSamsungFilter();//add filter Samsung
            case 4:
                PhoneSmartphoneXiaomiFilter(); //add filter Xiaomi
            case 5:
                list = electronicController.getElectronic(ElectronicCategory.Phone, "SELECT * FROM phones WHERE Category = 'Smartphone' AND not(`BrandName` = 'Samsung') AND not(`BrandName` = 'Iphone') AND not(`BrandName` = 'Xiaomi');");
                BuyItem();
            case 6:
                PhoneFilters(); //return previous method
        }
    }

    //////////////////////////////////////////////////////Samsung filters////////////////////////////////////////////////////////////
    public static void PhoneSmartphoneSamsungFilter() throws SQLException, ClassNotFoundException {
        System.out.println("\n" +
                "1.\tShow Samsungs\n" +
                "2.\tSammsung S\n" +
                "3.\tSamsung A\n" +
                "4.\tGo Back\n");
        int n = scanner.nextInt();
        scanner.nextLine();
        switch (n) {
            case 1:
                list = electronicController.getElectronic(ElectronicCategory.Phone, "SELECT * FROM phones WHERE BrandName = 'Samsung'");
                BuyItem();
                //shows all Samsungs
            case 2:
                PhoneSmartphoneSamsungModelFilter("S");//add filter Samsung S
            case 3:
                PhoneSmartphoneSamsungModelFilter("A");//add filter Samsung A
            case 4:
                PhoneSmartphoneFilter(); //return previous method
        }
    }

    public static void PhoneSmartphoneSamsungModelFilter(String number) throws SQLException, ClassNotFoundException {
        String model;
        System.out.print("1.\tShow Samsung" + number + "\n" +
                "       2.\tSamsung " + number);
        if (number == "S") {
            System.out.println(21);
            model = "21";
        } else {
            System.out.println(53);
            model = "53";
        }
        System.out.print("3.\tSamsung " + number);
        if (number == "S") {
            System.out.println(22);
            model = "22";
        } else {
            System.out.println(53);
            model = "73";
        }
        System.out.println("4.\tGo Back\n");

        int n = scanner.nextInt();
        scanner.nextLine();
        switch (n) {
            case 1:
                list = electronicController.getElectronic(ElectronicCategory.Phone, "SELECT * FROM phones WHERE BrandName = 'Samsung' and BrandSeries ='" + number + "'");
                BuyItem();
            case 2:
                list = electronicController.getElectronic(ElectronicCategory.Phone, "SELECT * FROM phones WHERE BrandName = 'Samsung' and BrandSeries ='" + number + "' and BrandSeriesNumber='" + model + "'");
                BuyItem();
            case 3:
                list = electronicController.getElectronic(ElectronicCategory.Phone, "SELECT * FROM phones WHERE BrandName = 'Samsung' and BrandSeries ='" + number + "' and BrandSeriesNumber='" + model + "'");
                BuyItem();
            case 4:
                PhoneSmartphoneSamsungFilter(); //return previous method
        }
    }

    //////////////////////////////////////////////////////Iphone filters////////////////////////////////////////////////////////////
    public static void PhoneSmartphoneIphoneFilter() throws SQLException, ClassNotFoundException {
        System.out.println("\n" +
                "1.\tShow Iphones\n" +
                "2.\tIphone 11\n" +
                "3.\tIphone 13\n" +
                "4.\tGo Back\n");
        int n = scanner.nextInt();
        scanner.nextLine();
        switch (n) {
            case 1:
                list = electronicController.getElectronic(ElectronicCategory.Phone, "SELECT * FROM phones WHERE BrandName = 'Iphone'");
                BuyItem();
                //shows all Iphones
            case 2:
                PhoneSmartphoneIphoneModelFilter("11");//add filter Iphone 11
            case 3:
                PhoneSmartphoneIphoneModelFilter("13");//add filter Iphone 13
            case 4:
                PhoneSmartphoneFilter(); //return previous method
        }
    }

    public static void PhoneSmartphoneIphoneModelFilter(String number) throws SQLException, ClassNotFoundException {
        System.out.println("\n" +
                "1.\tShow Iphone " + number + "\n" +
                "2.\tIphone " + number + " Pro\n" +
                "3.\tIphone " + number + " ProMax\n" +
                "4.\tGo Back\n");
        int n = scanner.nextInt();
        scanner.nextLine();
        switch (n) {
            case 1:
                list = electronicController.getElectronic(ElectronicCategory.Phone, "SELECT * FROM phones WHERE BrandName = 'Iphone' and BrandSeries ='" + number + "'");
                BuyItem();//shows all Iphones number
            case 2:
                list = electronicController.getElectronic(ElectronicCategory.Phone, "SELECT * FROM phones WHERE BrandName = 'Iphone' and BrandSeries ='" + number + "' and BrandSeriesNumber='Pro'");
                BuyItem();//add filter Iphone Pro
            case 3:
                list = electronicController.getElectronic(ElectronicCategory.Phone, "SELECT * FROM phones WHERE BrandName = 'Iphone' and BrandSeries ='" + number + "' and BrandSeriesNumber='Pro Max'");
                BuyItem();//add filter Iphone Max
            case 4:
                PhoneSmartphoneIphoneFilter(); //return previous method
        }
    }

    //////////////////////////////////////////////////////Xiaomi filters////////////////////////////////////////////////////////////
    public static void PhoneSmartphoneXiaomiFilter() throws SQLException, ClassNotFoundException {
        System.out.println("\n" +
                "1.\tShow Xiaomis\n" +
                "2.\tXiaomi 9\n" +
                "3.\tXiaomi 10\n" +
                "4.\tGo Back\n");
        int n = scanner.nextInt();
        scanner.nextLine();
        switch (n) {
            case 1:
                list = electronicController.getElectronic(ElectronicCategory.Phone, "SELECT * FROM phones WHERE BrandName = 'Xiaomi'");
                BuyItem();
                //shows all Xiaomi
            case 2:
                PhoneSmartphoneXiaomiModelFilter("9");//add filter Xiaomi 9
            case 3:
                PhoneSmartphoneXiaomiModelFilter("10");//add filter Xiaomi 10
            case 4:
                PhoneSmartphoneFilter(); //return previous method
        }
    }

    public static void PhoneSmartphoneXiaomiModelFilter(String number) throws SQLException, ClassNotFoundException {
        System.out.println("\n" +
                "1.\tShow Xiaomis " + number + "\n" +
                "2.\tXiaomi " + number + " A\n" +
                "3.\tXiaomi " + number + " B\n" +
                "4.\tGo Back\n");
        int n = scanner.nextInt();
        scanner.nextLine();
        switch (n) {
            case 1:
                list = electronicController.getElectronic(ElectronicCategory.Phone, "SELECT * FROM phones WHERE brandName = 'Xiaomi' and brandSeries ='" + number + "'");
                BuyItem();//shows all Xiaomi with this brandseries
            case 2:
                list = electronicController.getElectronic(ElectronicCategory.Phone, "SELECT * FROM phones WHERE BrandName = 'Samsung' and BrandSeries ='" + number + "' and BrandSeriesNumber='A'");
                BuyItem();//add filter Xiaomi A
            case 3:
                list = electronicController.getElectronic(ElectronicCategory.Phone, "SELECT * FROM phones WHERE BrandName = 'Samsung' and BrandSeries ='" + number + "' and BrandSeriesNumber='B'");
                BuyItem();//add filter Xiaomi  B
            case 4:
                PhoneSmartphoneXiaomiFilter(); //return previous method
        }
    }

    public static void BuyItem() {
        if (User.getInstance()) {
            System.out.println("Input id of item to add cart! if you want to go back input 0!");
            int choose = scanner.nextInt();
            if(choose ==0){ StartMarketPlace();}
            int i = findItemById((ArrayList<Electronic>) list,choose);
            Cart.getInstance("Object").addCart((Electronic) list.get(i));
            System.out.println("Item has been aded to cart!");
            StartMarketPlace();
        } else {
            System.out.println("You need to login!");
            signIn();
        }
    }

    public static int findItemById(ArrayList<Electronic> list, int id){
        for (int i = 0; i<list.size();i++){
            if(list.get(i).getId() == id){
                return i;
            }
        }
        return 0;
    }
    /////////////////////////////////////////////////Computer filters////////////////////////////////////////////////////////////////
    public static void ComputerFilter() throws SQLException, ClassNotFoundException {
        System.out.println("1.\tShow Computers\n" +
                "2.\tAdd filter Personal Computer\n" +
                "3.\tAdd filter Laptops\n" +
                "4.\tGo Back\n");
        int n = scanner.nextInt();
        scanner.nextLine();
        switch (n) {
            case 1:
                list = electronicController.getElectronic(ElectronicCategory.Computer, "SELECT * FROM computer");
                BuyItem();
            case 2:
                list = electronicController.getElectronic(ElectronicCategory.Computer, "SELECT * FROM computer WHERE Category ='Personal'");
                BuyItem();
            case 3:
                list = electronicController.getElectronic(ElectronicCategory.Computer, "SELECT * FROM computer WHERE Category = 'Laptop'");
                BuyItem();
            case 4:
                Filters(); //return previous method
        }
    }

    public static void TabletFilter() throws SQLException, ClassNotFoundException {
        System.out.println("1.\tShow Tablets\n" +
                "2.\tAdd filter Graphical tablets\n" +
                "3.\tAdd filter tablets for kids\n" +
                "4.\tGo Back\n");
        int n = scanner.nextInt();
        scanner.nextLine();
        switch (n) {
            case 1:
                list = electronicController.getElectronic(ElectronicCategory.Tablet, "SELECT * FROM tablet");
                BuyItem();
            case 2:
                list = electronicController.getElectronic(ElectronicCategory.Tablet, "SELECT * FROM tablet WHERE Category = 'Graphical'");
                BuyItem();
            case 3:
                list = electronicController.getElectronic(ElectronicCategory.Tablet, "SELECT * FROM tablet WHERE Category = 'Interactive'");
                BuyItem();
            case 4:
                Filters(); //return previous method
        }
    }
}


