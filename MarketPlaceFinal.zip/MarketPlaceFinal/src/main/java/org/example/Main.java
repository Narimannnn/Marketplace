package org.example;
import org.example.controllers.*;
import org.example.database.*;
import org.example.database.IDB;
import org.example.repositories.*;
import org.example.repositories.UserRepository;
import org.example.selectors.ElectronicSelector;

import java.sql.Connection;
import java.sql.Statement;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        IDB db = new ElectronicDb();
        IUserRepository repository = new UserRepository(db);
        UserController userController = new UserController(repository);

        ElectronicSelector selector = new ElectronicSelector();
        ElectronicsRepository electronicsRepository = new ElectronicsRepository(db,selector);
        ElectronicController electronicController = new ElectronicController(electronicsRepository);
        Application app = new Application(userController,electronicController);

        app.StartMarketPlace();


    }

}