package org.example.entities;

public class OtherElectronicDevice extends Electronic{
    private static final String electronicCategory = "Other devices";

    public OtherElectronicDevice(int id, String electronictypeofCategory, String electronicbrandName, double electronicWeight, int electronicPrice, String madeCountry) {
        super(id, OtherElectronicDevice.electronicCategory, electronictypeofCategory, electronicbrandName,electronicWeight, electronicPrice, madeCountry);
    }
}
