package org.example.entities;

import org.example.entities.*;

import java.util.ArrayList;

public class Cart {
    private static ArrayList<Electronic> cart = new ArrayList<>();
    private static Cart instance;
    public static void getCart() {
        for (int i=0; i < cart.size();i++){
            System.out.println(cart.get(i).toString());
        }
    }
    public void addCart(Electronic item) {
        cart.add(item);
    }
    public static Cart createInstance() {
        instance = new Cart();
        return instance;
    }
    public static boolean getInstance(){
        if(instance == null){
            return false;
        }
        return true;
    }
    public static Cart getInstance(String str){
        if(str == "Object"){
            if(instance == null){
                return null;
            }
            return instance;
        }
        return null;
    }
    public static String showCart(User user){
        int totalprice= 0;
        String string ="";
        if(Cart.instance != null){
            string = "This is " + User.getInstance("Object").getLogin() + "'s cart:";
            for(int i = 0;i< cart.size();i++){
                string = cart.get(i).toString();
                totalprice += cart.get(i).getElectronicPrice();
            }
        }else{
            string = "cart is empty!";
        }
        System.out.println("Total price:" + totalprice);
        return string;

    }
}
