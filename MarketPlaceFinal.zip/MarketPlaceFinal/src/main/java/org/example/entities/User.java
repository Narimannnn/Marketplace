package org.example.entities;

public class User {
    private static String login;
    private static String password;
    private static User instance = null;

    public static boolean getInstance() {
        if(instance == null){
            return false;
        }
        return true;
    }
    public static User getInstance(String str) {
        if (str == "Object") {
            return instance;
        }

        return null;
    }
    public static void setInstance() {
        instance= null;
    }
    public static User createInstance() {
        instance = new User();
        return instance;
    }
    private User(){}
    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        User.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        User.password = password;
    }
}
