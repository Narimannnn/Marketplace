package org.example.repositories;

import org.example.database.IDB;
import org.example.entities.Electronic;
import org.example.entities.Samsung;
import org.example.selectors.ElectronicSelector;
import org.example.selectors.categories.ElectronicCategory;
import org.example.selectors.categories.ElectronicCategoryType;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ElectronicsRepository {
    private final IDB db;
    private final ElectronicSelector selector;

    public ElectronicsRepository(IDB db, ElectronicSelector selector) {
        this.db = db;
        this.selector = selector;
    }

    public ArrayList<Electronic> getElectronic(ElectronicCategory electronicCategory, String sql) {
        Connection con = null;
        ArrayList<Electronic> electronics = new ArrayList<>();
        try {
            con = db.getConnection();
            Statement statement = con.createStatement();
            try {
                ResultSet resultset = statement.executeQuery(sql);
                while (resultset.next()) {
                    ArrayList<Object> list = new ArrayList<Object>();
                    if(ElectronicCategory.Phone == electronicCategory){
                        list.add(resultset.getInt(1));
                        list.add(resultset.getString(2));
                        list.add(resultset.getString(3));
                        list.add(resultset.getString(4));
                        list.add(resultset.getString((5)));
                        list.add(resultset.getInt(6));
                        list.add(resultset.getString(7));
                        list.add(resultset.getString(8));
                        list.add(resultset.getString(9));
                        list.add(resultset.getString(10));
                        list.add(resultset.getDouble(11));
                        list.add(resultset.getInt(12));
                        electronics.add(selector.createElectronic(electronicCategory, ElectronicCategoryType.valueOf((String) list.get(1)), (String) list.get(2), list));
                    }else if(ElectronicCategory.Tablet == electronicCategory){
                        list.add(resultset.getInt(1));
                        list.add(resultset.getString(2));
                        list.add(resultset.getString(3));
                        list.add(resultset.getString(4));
                        list.add(resultset.getString((5)));
                        list.add(resultset.getInt(6));
                        list.add(resultset.getString(7));
                        list.add(resultset.getString(8));
                        list.add(resultset.getString(9));
                        list.add(resultset.getDouble(10));
                        list.add(resultset.getInt(11));
                        electronics.add(selector.createElectronic(electronicCategory, ElectronicCategoryType.valueOf((String) list.get(1)), (String) list.get(2), list));
                    }else if(ElectronicCategory.Computer == electronicCategory){
                        list.add(resultset.getInt(1));
                        list.add(resultset.getString(2));
                        list.add(resultset.getString(3));
                        list.add(resultset.getString(4));
                        list.add(resultset.getString(5));
                        list.add(resultset.getInt(6));
                        list.add(resultset.getString(7));
                        list.add(resultset.getString(8));
                        list.add(resultset.getInt(9));
                        list.add(resultset.getInt(10));
                        list.add(resultset.getString(11));
                        list.add(resultset.getDouble(12));
                        list.add(resultset.getInt(13));
                        list.add(resultset.getString(14));
                        list.add(resultset.getString(15));
                        electronics.add(selector.createElectronic(electronicCategory, ElectronicCategoryType.valueOf((String) list.get(1)), (String) list.get(2), list));

                    }else if(ElectronicCategory.OtherElectronicDevice == electronicCategory){
                        list.add(resultset.getInt(1));
                        list.add(resultset.getString(2));
                        list.add(resultset.getString(3));
                        list.add(resultset.getDouble(4));
                        list.add(resultset.getInt(5));
                        list.add(resultset.getString(6));
                        electronics.add(selector.createElectronic(electronicCategory, null, (String) list.get(2), list));
                    }
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            return electronics;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    }
}
