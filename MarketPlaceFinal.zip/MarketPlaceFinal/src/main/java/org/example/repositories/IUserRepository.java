package org.example.repositories;

import org.example.entities.User;

import java.sql.SQLException;

public interface IUserRepository {
    boolean createUser(User user) throws SQLException;
    boolean userLogin(String login,String password);

}
