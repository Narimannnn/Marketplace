package org.example.repositories;
import com.mysql.cj.protocol.Resultset;
import org.example.database.IDB;
import org.example.entities.User;

import javax.swing.plaf.nimbus.State;
import java.sql.*;

public class UserRepository implements IUserRepository{
    private final IDB db;
    public UserRepository(IDB db){
        this.db = db;
    }

    @Override
    public boolean createUser(User user){
        Connection con = null;
        try{
            con = db.getConnection();
            String sql = "INSERT INTO users (id,username,password) VALUES (DEFAULT, ? , ?)";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1,user.getLogin());
            statement.setString(2,user.getPassword());
            statement.execute();
            return true;

        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
            try{
                con.close();
            }catch (SQLException e){
                e.printStackTrace();
            }

        }
    }

    @Override
    public boolean userLogin(String login,String password) {
        Connection con = null;
        try{
            con = db.getConnection();
            String sql = "SELECT * FROM users WHERE username = '" + login + "' AND password = '" + password + "'";
            Statement statement = con.createStatement();
            try {
                ResultSet resultset = statement.executeQuery(sql);
                if(resultset.next()){
                    int id = resultset.getInt(1);
                    if(id > 0){
                        return true;
                    }else{
                        return false;
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return false;
    }

}
